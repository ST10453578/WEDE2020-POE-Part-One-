// Enquiry Form Validation
function validateEnquiryForm() {
    const fullname = document.getElementById("fullname").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();

    if (fullname === "" || email === "" || message === "") {
        alert("Please complete all fields before submitting.");
        return false;
    }

    if (!email.includes("@") || !email.includes(".")) {
        alert("Invalid email address format.");
        return false;
    }

    alert("Thank you for your enquiry! We'll get back to you soon.");
    return true;
}
